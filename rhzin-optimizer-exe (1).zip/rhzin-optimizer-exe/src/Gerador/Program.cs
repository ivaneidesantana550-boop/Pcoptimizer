using System.Drawing;
using System.Windows.Forms;

namespace RHzin;

static class Program
{
    [STAThread]
    static void Main()
    {
        Application.SetHighDpiMode(HighDpiMode.SystemAware);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new GenForm());
    }
}

class GenForm : Form
{
    readonly TextBox dev;
    readonly TextBox outBox;
    readonly Label status;

    public GenForm()
    {
        Text = "RHzin — Gerador de Licença";
        ClientSize = new Size(480, 430);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        BackColor = T.Bg;
        ForeColor = T.Text;
        Font = new Font("Segoe UI", 10);

        Controls.Add(T.Lbl("Gerador de licença", 17, FontStyle.Bold, T.Acc, 20, 16));
        Controls.Add(T.Lbl("Computador: " + Environment.MachineName, 9, FontStyle.Regular, T.Mute, 22, 54));
        Controls.Add(T.Lbl("Nome do dispositivo", 9, FontStyle.Regular, T.Mute, 22, 86));
        dev = T.Box(22, 108, 436, false);
        dev.Text = Environment.MachineName;
        Controls.Add(dev);

        var gen = T.Btn("Gerar nova licença", 22, 150, 436, 40, true);
        gen.Click += (s, e) => Generate();
        Controls.Add(gen);

        outBox = new TextBox
        {
            Left = 22, Top = 204, Width = 436, Height = 110,
            Multiline = true, ReadOnly = true,
            BackColor = T.Card, ForeColor = T.Text,
            BorderStyle = BorderStyle.FixedSingle,
            Font = new Font("Consolas", 11)
        };
        Controls.Add(outBox);

        var copy = T.Btn("Copiar", 22, 326, 210, 36, false);
        copy.Click += (s, e) => { if (outBox.Text.Length > 0) { try { Clipboard.SetText(outBox.Text); } catch { } } };
        var rem = T.Btn("Remover licença", 248, 326, 210, 36, false);
        rem.Click += (s, e) => RemoveLic();
        Controls.Add(copy);
        Controls.Add(rem);

        status = T.Lbl("", 9, FontStyle.Regular, T.Mute, 22, 376, 436, 40);
        Controls.Add(status);
    }

    void Generate()
    {
        var name = dev.Text.Trim();
        if (name.Length == 0)
        {
            status.ForeColor = T.Warn;
            status.Text = "Informe o nome do dispositivo.";
            return;
        }
        try
        {
            var r = Auth.Create(name);
            outBox.Text = "LOGIN : " + r.login + "\r\nSENHA : " + r.pass + "\r\nKEY   : " + r.key;
            status.ForeColor = T.Acc;
            status.Text = "Licença vinculada a este computador. Guarde os três dados.";
        }
        catch (Exception ex)
        {
            status.ForeColor = T.Bad;
            status.Text = "Erro: " + ex.Message;
        }
    }

    void RemoveLic()
    {
        if (MessageBox.Show("Remover a licença deste computador?", "Remover", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        try
        {
            Auth.Remove();
            outBox.Clear();
            status.ForeColor = T.Acc;
            status.Text = "Licença removida.";
        }
        catch (Exception ex)
        {
            status.ForeColor = T.Bad;
            status.Text = "Erro: " + ex.Message;
        }
    }
}
