using System.Diagnostics;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace RHzin;

class Act
{
    public string Title;
    public string Desc;
    public Func<Task> Run;
    public string Confirm;
}

class Cat
{
    public string Name;
    public bool NotebookOnly;
    public List<Act> Acts = new List<Act>();
}

class MainForm : Form
{
    const string AppName = "RHzin Optimizer 4.0";

    const string PsCpu = "Get-CimInstance Win32_Processor | Select Name,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed | Format-List";
    const string PsGpu = "Get-CimInstance Win32_VideoController | Select Name,DriverVersion,DriverDate | Format-List";
    const string PsRamTotal = "Get-CimInstance Win32_ComputerSystem | Select @{N='RAM_GB';E={[math]::Round($_.TotalPhysicalMemory/1GB,2)}} | Format-List";
    const string PsRamFree = "Get-CimInstance Win32_OperatingSystem | Select @{N='Total_GB';E={[math]::Round($_.TotalVisibleMemorySize/1MB,2)}},@{N='Livre_GB';E={[math]::Round($_.FreePhysicalMemory/1MB,2)}} | Format-List";
    const string PsDisks = "Get-PhysicalDisk | Select FriendlyName,MediaType,HealthStatus,@{N='SizeGB';E={[math]::Round($_.Size/1GB,1)}} | Format-Table -Auto";
    const string PsVols = "Get-Volume | Where-Object { $_.DriveLetter } | Select DriveLetter,FileSystemLabel,@{N='Livre_GB';E={[math]::Round($_.SizeRemaining/1GB,1)}},@{N='Total_GB';E={[math]::Round($_.Size/1GB,1)}} | Format-Table -Auto";
    const string PsSys = "Get-CimInstance Win32_OperatingSystem | Select Caption,Version,OSArchitecture | Format-List; Get-CimInstance Win32_ComputerSystem | Select Manufacturer,Model | Format-List";
    const string PsTherm = "$t = Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction SilentlyContinue; if ($t) { $t | Select InstanceName,@{N='Celsius';E={[math]::Round(($_.CurrentTemperature/10)-273.15,1)}} | Format-Table -Auto } else { 'Este aparelho não expõe sensores ACPI. Use o HWiNFO ou o app do fabricante para ver temperaturas.' }";

    readonly bool detected = Sys.IsNotebook();
    readonly string logFile = Path.Combine(Auth.DataDir, "RHzin_Optimizer.log");
    int mode;
    List<Cat> cats = new List<Cat>();
    Cat cur;
    FlowLayoutPanel nav;
    FlowLayoutPanel cards;
    RichTextBox logBox;
    ProgressBar prog;
    Label sub;
    bool busy;

    bool Notebook { get { return mode == 1 || (mode == 0 && detected); } }

    public MainForm()
    {
        Text = AppName;
        Size = new Size(1180, 760);
        MinimumSize = new Size(980, 640);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = T.Bg;
        ForeColor = T.Text;
        Font = new Font("Segoe UI", 10);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2, BackColor = T.Bg, Margin = Padding.Empty };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 240));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 74));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var header = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = T.Side, Margin = Padding.Empty };
        header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 260));
        var left = new Panel { Dock = DockStyle.Fill, BackColor = T.Side };
        left.Controls.Add(T.Lbl("RHzin Optimizer", 17, FontStyle.Bold, T.Acc, 16, 6));
        sub = T.Lbl("", 9, FontStyle.Regular, T.Mute, 18, 44);
        left.Controls.Add(sub);
        var right = new Panel { Dock = DockStyle.Fill, BackColor = T.Side };
        right.Controls.Add(T.Lbl("Perfil do aparelho", 9, FontStyle.Regular, T.Mute, 8, 10));
        var cb = new ComboBox { Left = 8, Top = 32, Width = 220, DropDownStyle = ComboBoxStyle.DropDownList, FlatStyle = FlatStyle.Flat, BackColor = T.Card, ForeColor = T.Text };
        cb.Items.AddRange(new object[] { "Automático (detectar)", "Notebook", "PC desktop" });
        cb.SelectedIndex = 0;
        cb.SelectedIndexChanged += (s, e) => { mode = cb.SelectedIndex; BuildNav(); };
        right.Controls.Add(cb);
        header.Controls.Add(left, 0, 0);
        header.Controls.Add(right, 1, 0);
        root.Controls.Add(header, 0, 0);
        root.SetColumnSpan(header, 2);

        nav = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = true,
            BackColor = T.Side,
            Padding = new Padding(6, 8, 0, 8),
            Margin = Padding.Empty
        };
        root.Controls.Add(nav, 0, 1);

        var body = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, BackColor = T.Bg, Margin = Padding.Empty };
        body.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        body.RowStyles.Add(new RowStyle(SizeType.Absolute, 5));
        body.RowStyles.Add(new RowStyle(SizeType.Absolute, 220));
        cards = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = T.Bg, Padding = new Padding(8), Margin = Padding.Empty };
        prog = new ProgressBar { Dock = DockStyle.Fill, Style = ProgressBarStyle.Marquee, MarqueeAnimationSpeed = 0, Margin = Padding.Empty };
        logBox = new RichTextBox
        {
            Dock = DockStyle.Fill,
            ReadOnly = true,
            BackColor = Color.FromArgb(9, 14, 12),
            ForeColor = T.Mute,
            BorderStyle = BorderStyle.None,
            Font = new Font("Consolas", 9.5f),
            Margin = Padding.Empty
        };
        var menu = new ContextMenuStrip();
        menu.Items.Add("Limpar log", null, (s, e) => logBox.Clear());
        logBox.ContextMenuStrip = menu;
        body.Controls.Add(cards, 0, 0);
        body.Controls.Add(prog, 0, 1);
        body.Controls.Add(logBox, 0, 2);
        root.Controls.Add(body, 1, 1);
        Controls.Add(root);

        BuildNav();
        Log("== " + AppName + " pronto ==");
        Log("Escolha uma categoria à esquerda e toque em Executar. Alterações no Registro têm backup e podem ser desfeitas.");
    }

    // ---------- interface ----------
    void UpdateSub()
    {
        sub.Text = (Notebook ? "Notebook" : "PC desktop") + (mode == 0 ? " (detectado)" : "") +
            "  ·  " + Sys.OsName() + "  ·  " + Sys.RamGb().ToString("0.#") + " GB RAM" +
            "  ·  Licença: " + Auth.Resumo();
    }

    void BuildNav()
    {
        UpdateSub();
        var keep = cur == null ? null : cur.Name;
        cats = BuildCats().Where(c => !c.NotebookOnly || Notebook).ToList();
        nav.Controls.Clear();
        int i = 1;
        foreach (var c in cats)
        {
            var cat = c;
            var b = new Button
            {
                Text = i.ToString("00") + "  " + cat.Name,
                Width = 208,
                Height = 38,
                FlatStyle = FlatStyle.Flat,
                TextAlign = ContentAlignment.MiddleLeft,
                BackColor = T.Side,
                ForeColor = T.Text,
                Margin = new Padding(0, 1, 0, 1),
                Cursor = Cursors.Hand,
                Tag = cat.Name
            };
            b.FlatAppearance.BorderSize = 0;
            b.Click += (s, e) => SelectCat(cat);
            nav.Controls.Add(b);
            i++;
        }
        SelectCat(cats.FirstOrDefault(c => c.Name == keep) ?? cats[0]);
    }

    void SelectCat(Cat c)
    {
        cur = c;
        foreach (Control ctl in nav.Controls)
        {
            var on = (ctl.Tag as string) == c.Name;
            ctl.BackColor = on ? T.Card : T.Side;
            ctl.ForeColor = on ? T.Acc : T.Text;
        }
        cards.SuspendLayout();
        cards.Controls.Clear();
        foreach (var a in c.Acts) cards.Controls.Add(MakeCard(a));
        cards.ResumeLayout();
    }

    Panel MakeCard(Act a)
    {
        var p = new Panel { Width = 330, Height = 130, BackColor = T.Card, Margin = new Padding(8) };
        var t = T.Lbl(a.Title, 11, FontStyle.Bold, T.Text, 12, 8, 304, 24);
        t.AutoEllipsis = true;
        var d = T.Lbl(a.Desc, 9, FontStyle.Regular, T.Mute, 12, 34, 304, 58);
        var b = T.Btn("Executar", 216, 94, 100, 28, true);
        b.Click += async (s, e) => await RunAct(a);
        p.Controls.Add(t);
        p.Controls.Add(d);
        p.Controls.Add(b);
        return p;
    }

    async Task RunAct(Act a)
    {
        if (busy)
        {
            Log("[!] Aguarde a tarefa atual terminar.");
            return;
        }
        if (a.Confirm != null &&
            MessageBox.Show(a.Confirm, a.Title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        busy = true;
        prog.MarqueeAnimationSpeed = 30;
        Log("== " + a.Title + " ==");
        try
        {
            await a.Run();
        }
        catch (Exception ex)
        {
            Log("[X] Erro: " + ex.Message);
        }
        Log("-- concluído --");
        prog.MarqueeAnimationSpeed = 0;
        busy = false;
    }

    void Log(string s)
    {
        if (InvokeRequired)
        {
            try { BeginInvoke(new Action(() => Log(s))); } catch { }
            return;
        }
        Color c = T.Mute;
        if (s.StartsWith("[OK]")) c = T.Acc;
        else if (s.StartsWith("[!]")) c = T.Warn;
        else if (s.StartsWith("[X]")) c = T.Bad;
        else if (s.StartsWith("==")) c = T.Text;
        logBox.SelectionStart = logBox.TextLength;
        logBox.SelectionColor = c;
        logBox.AppendText(s + "\n");
        logBox.ScrollToCaret();
        try
        {
            Directory.CreateDirectory(Auth.DataDir);
            File.AppendAllText(logFile, "[" + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + "] " + s + "\n");
        }
        catch { }
    }

    string Ask(string title, string def)
    {
        using var f = new Form
        {
            Text = title,
            Size = new Size(390, 150),
            StartPosition = FormStartPosition.CenterParent,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            MaximizeBox = false,
            MinimizeBox = false,
            BackColor = T.Bg,
            ForeColor = T.Text
        };
        var tb = T.Box(14, 14, 350, false);
        tb.Text = def;
        var ok = T.Btn("OK", 264, 58, 100, 32, true);
        ok.DialogResult = DialogResult.OK;
        f.Controls.Add(tb);
        f.Controls.Add(ok);
        f.AcceptButton = ok;
        return f.ShowDialog(this) == DialogResult.OK ? tb.Text.Trim() : null;
    }

    // ---------- fabrica de acoes ----------
    Act Do(string t, string d, Func<Task> f, string confirm = null)
    {
        return new Act { Title = t, Desc = d, Run = f, Confirm = confirm };
    }

    Act Cmd(string t, string d, string file, string args, string confirm = null)
    {
        return new Act { Title = t, Desc = d, Confirm = confirm, Run = () => Sys.Exec(file, args, Log) };
    }

    Act Ps(string t, string d, string script)
    {
        return new Act { Title = t, Desc = d, Run = () => Sys.PS(script, Log) };
    }

    Act Go(string t, string d, string target)
    {
        return new Act
        {
            Title = t,
            Desc = d,
            Run = () => { Sys.Open(target, Log); return Task.CompletedTask; }
        };
    }

    // ---------- categorias ----------
    List<Cat> BuildCats()
    {
        string pwr = Notebook
            ? "Notebook: mantém o plano Equilibrado para poupar bateria e temperatura."
            : "PC: usa o plano Alto desempenho.";
        string hiConfirm = Notebook ? "No notebook, Alto desempenho aumenta consumo e temperatura. Continuar?" : null;
        var l = new List<Cat>();

        l.Add(new Cat { Name = "Otimização completa", Acts = {
            Do("Executar otimização completa", "Backup, todos os ajustes de desempenho do Registro, limpeza, energia e rede. " + pwr, Full, "Executar a otimização completa agora?") } });

        l.Add(new Cat { Name = "Otimização para jogos", Acts = {
            Do("Game Mode", "Ativa o modo de jogo automático do Windows.", GameMode),
            Do("Limpar temporários", "Apaga TEMP do usuário e do Windows.", CleanAll),
            Do("Plano de energia ideal", pwr, PowerAuto),
            Do("Pacote de jogos", "Game Mode, energia, rede básica e efeitos leves. " + pwr, () => GamePack(true)),
            Do("Limpar cache do FiveM", "Remove cache, server-cache e server-cache-priv do FiveM.", FiveMCache) } });

        l.Add(new Cat { Name = "CPU", Acts = {
            Ps("Informações da CPU", "Modelo, núcleos, threads e clock.", PsCpu),
            Do("Prioridade de primeiro plano", "Ajusta Win32PrioritySeparation para favorecer o programa em uso. Efeito pequeno; vale após reiniciar.", Prio),
            Do("Plano de energia ideal", pwr, PowerAuto) } });

        l.Add(new Cat { Name = "GPU", Acts = {
            Ps("Informações da GPU", "Modelo e versão do driver.", PsGpu),
            Go("Configurações gráficas", "Abre as configurações gráficas do Windows.", "ms-settings:display-advancedgraphics"),
            Do("Agendamento de GPU acelerado", "Liga o HAGS (HwSchMode=2). Só funciona com GPU e driver compatíveis; exige reinício.", GpuSched) } });

        l.Add(new Cat { Name = "RAM / Memória", Acts = {
            Ps("Memória instalada", "Total de RAM do aparelho.", PsRamTotal),
            Ps("Memória livre", "RAM total e livre agora.", PsRamFree),
            Do("Limpar temporários", "Apaga TEMP do usuário e do Windows.", CleanAll) } });

        l.Add(new Cat { Name = "SSD / HDD", Acts = {
            Ps("Discos físicos", "Modelo, tipo, saúde e tamanho.", PsDisks),
            Ps("Espaço livre", "Livre e total de cada unidade.", PsVols),
            Cmd("Ativar TRIM", "Garante que o TRIM esteja ligado para SSD.", "fsutil.exe", "behavior set DisableDeleteNotify 0"),
            Cmd("Otimizar unidade C:", "TRIM no SSD ou desfragmentação no HDD. Pode demorar.", "defrag.exe", "C: /O", "Otimizar a unidade C: agora? Pode demorar."),
            Do("Limpar temporários", "Apaga TEMP do usuário e do Windows.", CleanAll) } });

        l.Add(new Cat { Name = "Internet / Ping", Acts = {
            Do("Testar ping", "Mede a latência até um host (padrão 8.8.8.8).", PingTest),
            Cmd("Limpar DNS", "Esvazia o cache de DNS.", "ipconfig.exe", "/flushdns"),
            Do("Renovar IP", "Libera e renova o IP. A conexão cai por alguns segundos.", RenewIp, "A conexão vai cair por alguns segundos. Continuar?"),
            Cmd("Reset do Winsock", "Corrige falhas de rede. Exige reiniciar o Windows.", "netsh.exe", "winsock reset", "Resetar o Winsock? Será preciso reiniciar o Windows."),
            Do("Ajustes básicos de rede", "Limpa o DNS e deixa o TCP no padrão recomendado (autotuning normal, RSS ativo).", NetBasic) } });

        l.Add(new Cat { Name = "Windows 10 / 11", Acts = {
            Go("Versão do Windows", "Abre a janela Sobre o Windows.", "winver.exe"),
            Cmd("SFC /scannow", "Verifica e repara arquivos do sistema. Demora vários minutos.", "sfc.exe", "/scannow", "Rodar o SFC agora? Pode levar vários minutos."),
            Cmd("DISM ScanHealth", "Procura corrupção na imagem do Windows.", "DISM.exe", "/Online /Cleanup-Image /ScanHealth"),
            Cmd("DISM RestoreHealth", "Repara a imagem do Windows (precisa de internet).", "DISM.exe", "/Online /Cleanup-Image /RestoreHealth", "Rodar o DISM RestoreHealth? Pode demorar bastante."),
            Go("Windows Update", "Abre as atualizações do Windows.", "ms-settings:windowsupdate"),
            Go("Desempenho visual", "Abre as opções de desempenho do sistema.", "SystemPropertiesPerformance.exe") } });

        l.Add(new Cat { Name = "Limpeza do sistema", Acts = {
            Do("TEMP do usuário", "Apaga arquivos temporários do seu usuário.", CleanUser),
            Do("TEMP do Windows", "Apaga arquivos em Windows\\Temp.", CleanWin),
            Do("Cache do Windows Update", "Limpa SoftwareDistribution\\Download (pausa e reinicia os serviços).", CleanUpdate),
            Cmd("Limpar DNS", "Esvazia o cache de DNS.", "ipconfig.exe", "/flushdns"),
            Ps("Esvaziar lixeira", "Remove tudo da lixeira.", "Clear-RecycleBin -Force -ErrorAction SilentlyContinue; 'Lixeira esvaziada.'"),
            Do("Limpeza completa", "TEMP do usuário e do Windows com relatório do espaço liberado.", CleanAll) } });

        l.Add(new Cat { Name = "Energia / Desempenho", Acts = {
            Do("Alto desempenho", Notebook ? "Mais desempenho, mais consumo e calor. Pode não existir em notebooks com Modern Standby." : "Máximo desempenho do processador.", PowerHigh, hiConfirm),
            Do("Equilibrado", "Plano padrão do Windows.", PowerBal),
            Do("Plano ideal para este aparelho", pwr, PowerAuto),
            Cmd("Plano ativo", "Mostra o plano de energia atual.", "powercfg.exe", "/getactivescheme"),
            Cmd("Listar planos", "Lista os planos disponíveis.", "powercfg.exe", "/list"),
            Go("Configurações de energia", "Abre energia e suspensão.", "ms-settings:powersleep") } });

        l.Add(new Cat { Name = "Bateria (notebook)", NotebookOnly = true, Acts = {
            Do("Estado da bateria", "Carga, tomada e tempo restante.", BatteryStatus),
            Do("Relatório de bateria", "Gera e abre o relatório com capacidade de projeto e desgaste.", BatteryReport),
            Do("Relatório de energia", "Analisa por 15 segundos o que consome bateria.", EnergyReport),
            Go("Economia de bateria", "Abre as configurações de bateria do Windows.", "ms-settings:batterysaver") } });

        l.Add(new Cat { Name = "FiveM / GTA V / MTA", Acts = {
            Do("Limpar cache do FiveM", "Remove cache, server-cache e server-cache-priv.", FiveMCache),
            Go("Abrir pasta do FiveM", "Abre %LocalAppData%\\FiveM\\FiveM.app.", Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FiveM", "FiveM.app")),
            Do("Pacote de jogos", "Game Mode, energia, rede e efeitos leves. " + pwr, () => GamePack(true)),
            Ps("Informações do sistema", "Sistema, fabricante e modelo.", PsSys) } });

        var tw = new Cat { Name = "Tweaks por componente" };
        tw.Acts.AddRange(TweakCards());
        l.Add(tw);

        l.Add(new Cat { Name = "Diagnóstico", Acts = {
            Ps("CPU", "Modelo, núcleos e clock.", PsCpu),
            Ps("GPU", "Modelo e driver.", PsGpu),
            Ps("RAM", "Memória total e livre.", PsRamTotal + "; " + PsRamFree),
            Ps("Discos", "Saúde e espaço livre.", PsDisks + "; " + PsVols),
            Cmd("Rede", "Configuração completa de rede.", "ipconfig.exe", "/all"),
            Ps("Tudo", "Resumo completo do aparelho.", PsSys + "; " + PsCpu + "; " + PsGpu + "; " + PsRamTotal + "; " + PsDisks) } });

        l.Add(new Cat { Name = "Temperatura / Thermal", Acts = {
            Ps("Sensores ACPI", "Lê a temperatura quando o aparelho expõe os sensores.", PsTherm),
            Go("Gerenciador de Tarefas", "Acompanhe CPU, GPU e memória em tempo real.", "taskmgr.exe"),
            Go("Configurações de energia", "Abre energia e suspensão.", "ms-settings:powersleep") } });

        l.Add(new Cat { Name = "Backup / Restauração", Acts = {
            Do("Criar backup", "Salva os valores atuais e exporta as chaves do Registro usadas pelo programa.", Backup),
            Go("Abrir pasta de backups", "Abre a pasta com os backups.", Sys.BackupDir),
            Do("Restaurar backup mais recente", "Volta os valores do backup mais recente.", () => RestoreLast(true), "Restaurar o backup mais recente?"),
            Do("Restaurar tudo ao original", "Aplica todos os backups, do mais novo ao mais antigo, voltando ao estado inicial.", RestoreAll, "Restaurar tudo ao estado original?") } });

        l.Add(new Cat { Name = "Desfazer otimizações", Acts = {
            Do("Desfazer a última otimização", "Restaura exatamente os valores do Registro alterados na última vez.", () => RestoreLast(false), "Desfazer a última otimização?"),
            Do("Restaurar tudo ao original", "Volta ao estado de antes da primeira otimização.", RestoreAll, "Restaurar tudo ao estado original?"),
            Do("Energia equilibrada", "Ativa o plano Equilibrado.", PowerBal) } });

        l.Add(new Cat { Name = "Registro: desempenho", Acts = {
            Do("Ver o que será alterado", "Mostra no log cada valor do Registro, o atual e o novo, sem alterar nada.", PreviewBundle),
            Do("Aplicar todos os ajustes", "Aplica de uma vez os ajustes de Registro que afetam o desempenho, com backup. " +
                (Notebook ? "No notebook, os que gastam bateria ficam de fora." : "Inclui os ajustes pensados para PC."),
                ApplyBundle, "Aplicar todos os ajustes de desempenho do Registro?"),
            Do("Desfazer a última alteração", "Restaura exatamente os valores anteriores da última alteração.", () => RestoreLast(false), "Desfazer a última alteração do Registro?"),
            Do("Criar backup", "Salva os valores atuais e exporta as chaves usadas pelo programa.", Backup) } });

        l.Add(new Cat { Name = "Perfis de otimização", Acts = {
            Do("Aparelho muito antigo (até 4 GB)", "Limpeza, efeitos leves e energia ideal.", () => Profile(0), "Aplicar o perfil para aparelho antigo?"),
            Do("Aparelho básico (até 8 GB)", "Limpeza, efeitos leves e Game Mode.", () => Profile(1), "Aplicar o perfil básico?"),
            Do("Aparelho intermediário (até 16 GB)", "Pacote de jogos completo.", () => Profile(2), "Aplicar o perfil intermediário?"),
            Do("Aparelho potente (acima de 16 GB)", "Pacote de jogos sem reduzir os efeitos visuais.", () => Profile(3), "Aplicar o perfil potente?"),
            Do("Detectar automaticamente", "Escolhe o perfil pela quantidade de RAM.", AutoProfile, "Detectar e aplicar o perfil agora?") } });

        l.Add(new Cat { Name = "Informações do sistema", Acts = {
            Ps("Sistema e fabricante", "Windows, versão, arquitetura, fabricante e modelo.", PsSys),
            Ps("Processador", "Modelo e núcleos.", PsCpu),
            Ps("Placa de vídeo", "Modelo e driver.", PsGpu),
            Ps("Discos", "Tipo, saúde e tamanho.", PsDisks),
            Go("Abrir pasta de logs", "Abre %ProgramData%\\RHzin_Optimizer.", Auth.DataDir) } });

        l.Add(new Cat { Name = "Ferramentas do Windows", Acts = {
            Go("Gerenciador de Tarefas", "Processos e desempenho.", "taskmgr.exe"),
            Go("Gerenciador de Dispositivos", "Drivers e hardware.", "devmgmt.msc"),
            Go("Serviços", "Serviços do Windows.", "services.msc"),
            Go("Painel de Controle", "Painel de Controle clássico.", "control.exe"),
            Go("Informações do Sistema", "msinfo32.", "msinfo32.exe"),
            Go("Gerenciamento de Disco", "Partições e unidades.", "diskmgmt.msc"),
            Go("Prompt de Comando", "Abre o CMD.", "cmd.exe"),
            Go("PowerShell", "Abre o PowerShell.", "powershell.exe") } });

        return l;
    }

    // ---------- tarefas ----------
    async Task Full()
    {
        await ApplyBundle();
        await CleanAll();
        await PowerAuto();
        await NetBasic();
        Log("[OK] Otimização completa concluída. Efeitos visuais podem exigir sair e entrar no Windows.");
    }

    async Task CleanUser()
    {
        var n = await Task.Run(() => Sys.CleanDir(Path.GetTempPath()));
        Log("[OK] TEMP do usuário limpo: " + Sys.Mb(n) + " liberados.");
    }

    async Task CleanWin()
    {
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Temp");
        var n = await Task.Run(() => Sys.CleanDir(dir));
        Log("[OK] TEMP do Windows limpo: " + Sys.Mb(n) + " liberados.");
    }

    async Task CleanUpdate()
    {
        await Sys.Exec("net.exe", "stop wuauserv /y", null);
        await Sys.Exec("net.exe", "stop bits /y", null);
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "SoftwareDistribution", "Download");
        var n = await Task.Run(() => Sys.CleanDir(dir));
        await Sys.Exec("net.exe", "start bits", null);
        await Sys.Exec("net.exe", "start wuauserv", null);
        Log("[OK] Cache do Windows Update limpo: " + Sys.Mb(n) + " liberados.");
    }

    async Task CleanAll()
    {
        await CleanUser();
        await CleanWin();
    }

    Task ApplyTweak(Tweak t)
    {
        return Sys.ApplyTweaks(t.Id, t.Values, t.Title + " aplicado", Log);
    }

    Task GameMode() { return ApplyTweak(Tweaks.Get("game_mode")); }
    Task Prio() { return ApplyTweak(Tweaks.Get("cpu_prio")); }
    Task Visual() { return ApplyTweak(Tweaks.Get("ui_visual")); }

    async Task GpuSched()
    {
        await ApplyTweak(Tweaks.Get("gpu_hags"));
        Log("[!] Só tem efeito com GPU e driver compatíveis (WDDM 2.7+). Reinicie o Windows.");
    }

    Tweak[] BundleList()
    {
        var ram = Sys.RamGb();
        return Tweaks.Catalog.Where(t => t.InBundle && !(Notebook && t.PcOnly) && ram + 0.6 >= t.MinRamGb).ToArray();
    }

    async Task ApplyBundle()
    {
        var list = BundleList();
        foreach (var t in Tweaks.Catalog.Where(x => x.InBundle && !list.Contains(x)))
            Log("[!] Ignorado neste aparelho: " + t.Title + (Notebook && t.PcOnly ? " (gasta bateria no notebook)" : " (precisa de mais RAM)"));
        var vals = list.SelectMany(t => t.Values).ToArray();
        await Sys.ApplyTweaks("registro_total", vals, list.Length + " ajustes de desempenho aplicados", Log);
        Log("[!] Reinicie o Windows para todos os ajustes entrarem em vigor.");
    }

    Task PreviewBundle()
    {
        var list = BundleList();
        Log("Valores que serão gravados (atual -> novo):");
        foreach (var t in list)
        {
            Log("• " + t.Group + " · " + t.Title);
            Sys.Preview(t.Values, Log);
        }
        return Task.CompletedTask;
    }

    List<Act> TweakCards()
    {
        var l = new List<Act>();
        foreach (var t in Tweaks.Catalog)
        {
            var tw = t;
            var conf = tw.Confirm;
            if (Notebook && tw.PcOnly) conf = "Este ajuste é para PC e gasta mais bateria no notebook. Aplicar mesmo assim?";
            l.Add(Do("[" + tw.Group + "] " + tw.Title, tw.Desc, () => ApplyTweak(tw), conf));
        }
        l.Add(Do("[CPU] Plano de energia ideal", Notebook ? "Notebook: plano Equilibrado." : "PC: plano Alto desempenho.", PowerAuto));
        l.Add(Cmd("[Disco] Ativar TRIM", "Garante que o TRIM esteja ligado para SSD.", "fsutil.exe", "behavior set DisableDeleteNotify 0"));
        return l;
    }

    async Task PowerHigh()
    {
        var r = await Sys.Exec("powercfg.exe", "/setactive SCHEME_MIN", Log);
        Log(r == 0 ? "[OK] Plano Alto desempenho ativo." : "[!] Plano Alto desempenho indisponível neste aparelho.");
    }

    async Task PowerBal()
    {
        var r = await Sys.Exec("powercfg.exe", "/setactive SCHEME_BALANCED", Log);
        Log(r == 0 ? "[OK] Plano Equilibrado ativo." : "[!] Não foi possível ativar o plano Equilibrado.");
    }

    Task PowerAuto() { return Notebook ? PowerBal() : PowerHigh(); }

    async Task NetBasic()
    {
        await Sys.Exec("ipconfig.exe", "/flushdns", null);
        await Sys.Exec("netsh.exe", "interface tcp set global autotuninglevel=normal", null);
        await Sys.Exec("netsh.exe", "interface tcp set global rss=enabled", null);
        Log("[OK] DNS limpo e TCP no padrão recomendado (autotuning normal, RSS ativo).");
    }

    async Task GamePack(bool visual)
    {
        await GameMode();
        await PowerAuto();
        await NetBasic();
        if (visual) await Visual();
        Log("[OK] Pacote de jogos concluído.");
    }

    async Task Profile(int p)
    {
        if (p == 0)
        {
            await CleanAll();
            await Visual();
            await PowerAuto();
        }
        else if (p == 1)
        {
            await CleanAll();
            await Visual();
            await GameMode();
        }
        else if (p == 2)
        {
            await GamePack(true);
        }
        else
        {
            await GamePack(false);
        }
        Log("[OK] Perfil aplicado.");
    }

    async Task AutoProfile()
    {
        var gb = Math.Round(Sys.RamGb());
        Log("RAM detectada: " + gb + " GB");
        await Profile(gb <= 4 ? 0 : gb <= 8 ? 1 : gb <= 16 ? 2 : 3);
    }

    async Task FiveMCache()
    {
        var root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FiveM", "FiveM.app", "data");
        if (!Directory.Exists(root))
        {
            Log("[!] FiveM não encontrado em " + root);
            return;
        }
        long total = 0;
        await Task.Run(() =>
        {
            foreach (var d in new[] { "cache", "server-cache", "server-cache-priv" })
                total += Sys.CleanDir(Path.Combine(root, d));
        });
        Log("[OK] Cache do FiveM limpo: " + Sys.Mb(total) + " liberados. Feche o FiveM antes para limpar tudo.");
    }

    async Task PingTest()
    {
        var h = Ask("Host para testar", "8.8.8.8");
        if (string.IsNullOrEmpty(h) || !Regex.IsMatch(h, @"^[A-Za-z0-9.\-:]+$"))
        {
            Log("[!] Host inválido.");
            return;
        }
        await Sys.Exec("ping.exe", "-n 5 " + h, Log);
    }

    async Task RenewIp()
    {
        await Sys.Exec("ipconfig.exe", "/release", Log);
        await Sys.Exec("ipconfig.exe", "/renew", Log);
    }

    Task Backup()
    {
        return Sys.ApplyTweaks("manual", Tweaks.All, "", Log, false);
    }

    Task RestoreLast(bool includeManual)
    {
        var s = Sys.Snaps().Where(f => includeManual || !f.Contains("_manual")).ToArray();
        if (s.Length == 0)
        {
            Log("[!] Nenhum backup encontrado. Aplique uma otimização ou crie um backup antes.");
            return Task.CompletedTask;
        }
        var n = Sys.RestoreFile(s[0], Log);
        Log("[OK] Restaurado: " + Path.GetFileName(s[0]) + " (" + n + " valores).");
        return Task.CompletedTask;
    }

    Task RestoreAll()
    {
        var s = Sys.Snaps();
        if (s.Length == 0)
        {
            Log("[!] Nenhum backup encontrado.");
            return Task.CompletedTask;
        }
        int n = 0;
        foreach (var f in s) n += Sys.RestoreFile(f, Log);
        Log("[OK] " + s.Length + " backups aplicados, " + n + " valores restaurados.");
        return Task.CompletedTask;
    }

    Task BatteryStatus()
    {
        var ps = SystemInformation.PowerStatus;
        var pct = ps.BatteryLifePercent;
        Log("Carga: " + (pct >= 0 && pct <= 1 ? ((int)(pct * 100)) + "%" : "desconhecida"));
        Log("Energia: " + (ps.PowerLineStatus == PowerLineStatus.Online ? "ligado na tomada" : "na bateria"));
        var sec = ps.BatteryLifeRemaining;
        if (sec > 0) Log("Tempo restante estimado: " + (sec / 3600) + " h " + (sec % 3600 / 60) + " min");
        return Task.CompletedTask;
    }

    async Task BatteryReport()
    {
        Directory.CreateDirectory(Sys.ReportDir);
        var f = Path.Combine(Sys.ReportDir, "bateria.html");
        var r = await Sys.Exec("powercfg.exe", "/batteryreport /output \"" + f + "\"", Log);
        if (r == 0 && File.Exists(f))
        {
            Log("[OK] Relatório gerado: " + f);
            Sys.Open(f, Log);
        }
        else Log("[!] Não foi possível gerar o relatório de bateria.");
    }

    async Task EnergyReport()
    {
        Directory.CreateDirectory(Sys.ReportDir);
        var f = Path.Combine(Sys.ReportDir, "energia.html");
        Log("Analisando por 15 segundos. Deixe o aparelho em uso normal.");
        var r = await Sys.Exec("powercfg.exe", "/energy /output \"" + f + "\" /duration 15", Log);
        if (File.Exists(f))
        {
            Log("[OK] Relatório gerado: " + f);
            Sys.Open(f, Log);
        }
        else Log("[!] Não foi possível gerar o relatório de energia (código " + r + ").");
    }
}
