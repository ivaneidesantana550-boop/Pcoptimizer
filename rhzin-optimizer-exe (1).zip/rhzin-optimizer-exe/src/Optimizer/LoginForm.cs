using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace RHzin;

class LoginForm : Form
{
    readonly TextBox u;
    readonly TextBox p;
    readonly TextBox k;
    readonly Label err;
    int tries;

    public LoginForm()
    {
        Text = "RHzin Optimizer — Acesso";
        ClientSize = new Size(420, 470);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        BackColor = T.Bg;
        ForeColor = T.Text;
        Font = new Font("Segoe UI", 10);

        var lic = Auth.Read();
        Controls.Add(T.Lbl("RHzin Optimizer", 19, FontStyle.Bold, T.Acc, 24, 18));
        Controls.Add(T.Lbl("Acesso seguro", 10, FontStyle.Regular, T.Mute, 27, 60));
        Controls.Add(T.Lbl(lic == null ? "Nenhuma licença neste computador." : "Dispositivo: " + lic.Device,
            9, FontStyle.Regular, lic == null ? T.Warn : T.Mute, 27, 90, 366, 22));

        Controls.Add(T.Lbl("Login", 9, FontStyle.Regular, T.Mute, 27, 128));
        u = T.Box(27, 150, 366, false);
        Controls.Add(u);
        Controls.Add(T.Lbl("Senha", 9, FontStyle.Regular, T.Mute, 27, 190));
        p = T.Box(27, 212, 366, true);
        Controls.Add(p);
        Controls.Add(T.Lbl("Key", 9, FontStyle.Regular, T.Mute, 27, 252));
        k = T.Box(27, 274, 366, false);
        Controls.Add(k);

        err = T.Lbl("", 9, FontStyle.Regular, T.Bad, 27, 314, 366, 36);
        Controls.Add(err);

        var ok = T.Btn("Entrar", 27, 356, 366, 40, true);
        ok.Click += (s, e) => TryLogin();
        Controls.Add(ok);
        AcceptButton = ok;

        if (lic == null)
        {
            var g = T.Btn("Abrir gerador de licença", 27, 408, 366, 36, false);
            g.Click += (s, e) =>
            {
                var dir = Path.GetDirectoryName(Environment.ProcessPath) ?? "";
                var exe = Path.Combine(dir, "RHzin_Gerador_Licenca.exe");
                if (File.Exists(exe)) Process.Start(new ProcessStartInfo(exe) { UseShellExecute = true });
                else err.Text = "RHzin_Gerador_Licenca.exe não está na mesma pasta deste programa.";
            };
            Controls.Add(g);
        }
    }

    void TryLogin()
    {
        var msg = Auth.Validate(u.Text.Trim(), p.Text.Trim(), k.Text.Trim());
        if (msg == null)
        {
            DialogResult = DialogResult.OK;
            return;
        }
        tries++;
        err.Text = msg;
        p.Clear();
        if (tries >= 5) DialogResult = DialogResult.Cancel;
    }
}
