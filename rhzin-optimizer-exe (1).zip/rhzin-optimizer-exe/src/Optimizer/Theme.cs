using System.Drawing;
using System.Windows.Forms;

namespace RHzin;

static class T
{
    public static readonly Color Bg = Color.FromArgb(15, 21, 18);
    public static readonly Color Side = Color.FromArgb(18, 27, 23);
    public static readonly Color Card = Color.FromArgb(25, 36, 31);
    public static readonly Color Line = Color.FromArgb(38, 54, 46);
    public static readonly Color Text = Color.FromArgb(230, 242, 236);
    public static readonly Color Mute = Color.FromArgb(141, 165, 151);
    public static readonly Color Acc = Color.FromArgb(25, 195, 125);
    public static readonly Color Warn = Color.FromArgb(232, 163, 23);
    public static readonly Color Bad = Color.FromArgb(229, 72, 77);

    public static Label Lbl(string text, float size, FontStyle style, Color color, int x, int y, int w = 0, int h = 0)
    {
        var l = new Label
        {
            Text = text,
            ForeColor = color,
            BackColor = Color.Transparent,
            Font = new Font("Segoe UI", size, style),
            Left = x,
            Top = y
        };
        if (w > 0)
        {
            l.AutoSize = false;
            l.Width = w;
            l.Height = h > 0 ? h : 24;
        }
        else
        {
            l.AutoSize = true;
        }
        return l;
    }

    public static Button Btn(string text, int x, int y, int w, int h, bool primary)
    {
        var b = new Button
        {
            Text = text,
            Left = x,
            Top = y,
            Width = w,
            Height = h,
            FlatStyle = FlatStyle.Flat,
            Cursor = Cursors.Hand,
            BackColor = primary ? Acc : Card,
            ForeColor = primary ? Color.Black : Text,
            Font = new Font("Segoe UI", 10, FontStyle.Bold)
        };
        b.FlatAppearance.BorderSize = primary ? 0 : 1;
        b.FlatAppearance.BorderColor = Line;
        return b;
    }

    public static TextBox Box(int x, int y, int w, bool password)
    {
        return new TextBox
        {
            Left = x,
            Top = y,
            Width = w,
            BackColor = Card,
            ForeColor = Text,
            BorderStyle = BorderStyle.FixedSingle,
            UseSystemPasswordChar = password,
            Font = new Font("Segoe UI", 11)
        };
    }
}
