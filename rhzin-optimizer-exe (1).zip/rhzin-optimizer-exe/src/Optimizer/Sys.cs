using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace RHzin;

public record Tw(string Key, string Name, object Value);

public class Tweak
{
    public string Id;
    public string Group;
    public string Title;
    public string Desc;
    public Tw[] Values;
    public bool InBundle = true;   // entra em "Aplicar todos os ajustes"
    public bool PcOnly;            // fora do pacote no notebook (gasta bateria)
    public int MinRamGb;           // 0 = sem exigência de RAM
    public string Confirm;         // pergunta antes de aplicar (ajustes com efeito colateral)
}

static class Tweaks
{
    const string CU = @"HKEY_CURRENT_USER\";
    const string LM = @"HKEY_LOCAL_MACHINE\";
    const string Adv = @"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced";
    const string Prof = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile";
    const string Desk = @"Control Panel\Desktop";

    static Tw D(string key, string name, int v) { return new Tw(key, name, v); }
    static Tw S(string key, string name, string v) { return new Tw(key, name, v); }

    public static readonly Tweak[] Catalog =
    {
        // ---------- CPU ----------
        new Tweak
        {
            Id = "cpu_prio", Group = "CPU", Title = "Prioridade em primeiro plano",
            Desc = "Dá mais tempo de CPU ao programa em uso (Win32PrioritySeparation 38). Efeito pequeno. Reinicie.",
            Values = new[] { D(LM + @"SYSTEM\CurrentControlSet\Control\PriorityControl", "Win32PrioritySeparation", 38) }
        },
        new Tweak
        {
            Id = "mmcss", Group = "CPU", Title = "Agendador multimídia (MMCSS)",
            Desc = "Reserva menos CPU para multimídia em segundo plano (SystemResponsiveness 10; padrão 20).",
            Values = new[] { D(LM + Prof, "SystemResponsiveness", 10) }
        },
        new Tweak
        {
            Id = "cpu_pt", Group = "CPU", Title = "Power Throttling desligado",
            Desc = "Impede o Windows de limitar processos em segundo plano. Para PC; no notebook gasta bateria.",
            PcOnly = true,
            Values = new[] { D(LM + @"SYSTEM\CurrentControlSet\Control\Power\PowerThrottling", "PowerThrottlingOff", 1) }
        },
        // ---------- Jogos / GPU ----------
        new Tweak
        {
            Id = "game_mode", Group = "Jogos", Title = "Game Mode ligado",
            Desc = "Ativa o Modo de Jogo automático do Windows, que prioriza o jogo em uso.",
            Values = new[]
            {
                D(CU + @"Software\Microsoft\GameBar", "AllowAutoGameMode", 1),
                D(CU + @"Software\Microsoft\GameBar", "AutoGameModeEnabled", 1)
            }
        },
        new Tweak
        {
            Id = "game_dvr", Group = "Jogos", Title = "Game DVR desligado",
            Desc = "Desliga a captura em segundo plano do Xbox (Game DVR), que consome CPU e GPU.",
            Values = new[]
            {
                D(CU + @"SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR", "AppCaptureEnabled", 0),
                D(CU + @"System\GameConfigStore", "GameDVR_Enabled", 0),
                D(LM + @"SOFTWARE\Policies\Microsoft\Windows\GameDVR", "AllowGameDVR", 0)
            }
        },
        new Tweak
        {
            Id = "mmcss_games", Group = "Jogos", Title = "Perfil MMCSS para jogos",
            Desc = "Sobe a prioridade do perfil Games do MMCSS. Só afeta programas que usam esse perfil.",
            Values = new[]
            {
                D(LM + Prof + @"\Tasks\Games", "GPU Priority", 8),
                D(LM + Prof + @"\Tasks\Games", "Priority", 6),
                S(LM + Prof + @"\Tasks\Games", "Scheduling Category", "High"),
                S(LM + Prof + @"\Tasks\Games", "SFIO Priority", "High")
            }
        },
        new Tweak
        {
            Id = "gpu_hags", Group = "Jogos", Title = "Agendamento de GPU (HAGS)",
            Desc = "Liga o agendamento de GPU por hardware. Exige GPU e driver compatíveis; o efeito varia por jogo. Reinicie.",
            InBundle = false,
            Values = new[] { D(LM + @"SYSTEM\CurrentControlSet\Control\GraphicsDrivers", "HwSchMode", 2) }
        },
        // ---------- Memória ----------
        new Tweak
        {
            Id = "mem_paging", Group = "Memória", Title = "Núcleo do Windows na RAM",
            Desc = "Mantém o núcleo do Windows na RAM em vez do arquivo de paginação. Indicado com 16 GB ou mais.",
            MinRamGb = 16,
            Values = new[] { D(LM + @"SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management", "DisablePagingExecutive", 1) }
        },
        // ---------- Disco ----------
        new Tweak
        {
            Id = "disk_atime", Group = "Disco", Title = "Sem registro de último acesso",
            Desc = "Para de gravar a data de último acesso de cada arquivo. Menos escrita; ajuda mais em HDD. Reinicie.",
            Values = new[] { D(LM + @"SYSTEM\CurrentControlSet\Control\FileSystem", "NtfsDisableLastAccessUpdate", -2147483647) }
        },
        // ---------- Rede ----------
        new Tweak
        {
            Id = "net_throttle", Group = "Rede", Title = "Sem limite de rede multimídia",
            Desc = "Remove o limite de pacotes durante multimídia (NetworkThrottlingIndex). Efeito pequeno e varia.",
            Values = new[] { D(LM + Prof, "NetworkThrottlingIndex", -1) }
        },
        new Tweak
        {
            Id = "net_do", Group = "Rede", Title = "Sem envio P2P de atualizações",
            Desc = "Impede o PC de enviar atualizações do Windows a outros PCs, economizando banda e processamento.",
            Values = new[] { D(LM + @"SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization", "DODownloadMode", 0) }
        },
        // ---------- Interface ----------
        new Tweak
        {
            Id = "ui_visual", Group = "Visual", Title = "Efeitos visuais leves",
            Desc = "Desliga transparência e animações. Parte só vale após sair e entrar no Windows.",
            Values = new[]
            {
                D(CU + @"Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects", "VisualFXSetting", 2),
                D(CU + @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize", "EnableTransparency", 0),
                D(CU + Adv, "TaskbarAnimations", 0),
                D(CU + Adv, "ListviewAlphaSelect", 0),
                D(CU + Adv, "ListviewShadow", 0),
                D(CU + @"Software\Microsoft\Windows\DWM", "EnableAeroPeek", 0),
                S(CU + Desk + @"\WindowMetrics", "MinAnimate", "0")
            }
        },
        new Tweak
        {
            Id = "ui_menu", Group = "Visual", Title = "Menus sem atraso",
            Desc = "Menus abrem sem espera (MenuShowDelay 0; padrão 400 ms). Vale após sair e entrar no Windows.",
            Values = new[] { S(CU + Desk, "MenuShowDelay", "0") }
        },
        new Tweak
        {
            Id = "ui_startup", Group = "Visual", Title = "Sem atraso ao iniciar apps",
            Desc = "Remove o atraso artificial dos programas de inicialização do Windows.",
            Values = new[] { D(CU + @"Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize", "StartupDelayInMSec", 0) }
        },
        // ---------- Segundo plano (com efeito colateral: ficam fora do pacote) ----------
        new Tweak
        {
            Id = "bg_apps", Group = "Fundo", Title = "Apps em 2º plano desligados",
            Desc = "Apps da Microsoft Store não rodam em segundo plano. Podem parar de notificar.",
            InBundle = false,
            Confirm = "Apps da Microsoft Store deixam de rodar em segundo plano e podem parar de notificar. Continuar?",
            Values = new[] { D(LM + @"SOFTWARE\Policies\Microsoft\Windows\AppPrivacy", "LetAppsRunInBackground", 2) }
        },
        new Tweak
        {
            Id = "shutdown", Group = "Fundo", Title = "Desligamento mais rápido",
            Desc = "Reduz para 2 s a espera por programas e serviços ao desligar. Menos tempo para salvar.",
            InBundle = false,
            Confirm = "Programas e serviços terão menos tempo para salvar ao desligar. Continuar?",
            Values = new[]
            {
                S(LM + @"SYSTEM\CurrentControlSet\Control", "WaitToKillServiceTimeout", "2000"),
                S(CU + Desk, "WaitToKillAppTimeout", "2000"),
                S(CU + Desk, "HungAppTimeout", "2000")
            }
        }
    };

    public static Tweak Get(string id)
    {
        return Catalog.First(t => t.Id == id);
    }

    public static Tw[] All
    {
        get { return Catalog.SelectMany(t => t.Values).ToArray(); }
    }
}

static class Sys
{
    [StructLayout(LayoutKind.Sequential)]
    struct MEMSTATUSEX
    {
        public uint dwLength;
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    static extern bool GlobalMemoryStatusEx(ref MEMSTATUSEX lpBuffer);

    static readonly Encoding Oem = GetOem();

    static Encoding GetOem()
    {
        try
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            return Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage);
        }
        catch
        {
            return Encoding.UTF8;
        }
    }

    public static string BackupDir { get { return Path.Combine(Auth.DataDir, "Backups"); } }
    public static string ReportDir { get { return Path.Combine(Auth.DataDir, "Reports"); } }

    // ---------- hardware ----------
    public static bool IsNotebook()
    {
        try
        {
            var s = SystemInformation.PowerStatus.BatteryChargeStatus;
            return (s & BatteryChargeStatus.NoSystemBattery) == 0;
        }
        catch
        {
            return false;
        }
    }

    public static double RamGb()
    {
        var m = new MEMSTATUSEX();
        m.dwLength = (uint)Marshal.SizeOf<MEMSTATUSEX>();
        if (!GlobalMemoryStatusEx(ref m)) return 0;
        return m.ullTotalPhys / 1073741824.0;
    }

    public static string OsName()
    {
        return Environment.OSVersion.Version.Build >= 22000 ? "Windows 11" : "Windows 10";
    }

    public static string Mb(long bytes)
    {
        return (bytes / 1048576.0).ToString("0.0", CultureInfo.CurrentCulture) + " MB";
    }

    // ---------- processos ----------
    public static async Task<int> Exec(string file, string args, Action<string> log)
    {
        var psi = new ProcessStartInfo(file, args)
        {
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            StandardOutputEncoding = Oem,
            StandardErrorEncoding = Oem
        };
        using var p = new Process { StartInfo = psi };
        DataReceivedEventHandler h = (s, e) =>
        {
            if (log == null || e.Data == null) return;
            var line = e.Data.Replace("\0", "").TrimEnd();
            if (line.Trim().Length > 0) log(line);
        };
        p.OutputDataReceived += h;
        p.ErrorDataReceived += h;
        try
        {
            p.Start();
        }
        catch (Exception ex)
        {
            if (log != null) log("[X] Não foi possível executar " + file + ": " + ex.Message);
            return -1;
        }
        p.BeginOutputReadLine();
        p.BeginErrorReadLine();
        await p.WaitForExitAsync();
        return p.ExitCode;
    }

    public static Task<int> PS(string script, Action<string> log)
    {
        var full = "$ProgressPreference='SilentlyContinue';" + script;
        var enc = Convert.ToBase64String(Encoding.Unicode.GetBytes(full));
        return Exec("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -EncodedCommand " + enc, log);
    }

    public static void Open(string target, Action<string> log)
    {
        try
        {
            Process.Start(new ProcessStartInfo(target) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            if (log != null) log("[!] Não foi possível abrir " + target + ": " + ex.Message);
        }
    }

    // ---------- limpeza ----------
    public static long CleanDir(string path)
    {
        long freed = 0;
        if (!Directory.Exists(path)) return 0;
        try
        {
            foreach (var f in Directory.EnumerateFiles(path))
            {
                try
                {
                    var fi = new FileInfo(f);
                    var len = fi.Length;
                    fi.IsReadOnly = false;
                    fi.Delete();
                    freed += len;
                }
                catch { }
            }
            foreach (var d in Directory.EnumerateDirectories(path))
            {
                try
                {
                    // nunca entra em junctions/links simbolicos
                    if ((File.GetAttributes(d) & FileAttributes.ReparsePoint) == 0) freed += CleanDir(d);
                    Directory.Delete(d, false);
                }
                catch { }
            }
        }
        catch { }
        return freed;
    }

    // ---------- registro com backup e desfazer exato ----------
    public static async Task ApplyTweaks(string label, Tw[] list, string okMsg, Action<string> log, bool apply = true)
    {
        Directory.CreateDirectory(BackupDir);
        var stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        var snap = new List<string>();
        var todo = new List<Tw>();
        foreach (var t in list)
        {
            object cur = null;
            try { cur = Registry.GetValue(t.Key, t.Name, null); } catch { }
            if (cur == null)
            {
                snap.Add(t.Key + "\t" + t.Name + "\t-");
            }
            else if (cur is int ci)
            {
                snap.Add(t.Key + "\t" + t.Name + "\tD:" + ci);
            }
            else if (cur is string cs)
            {
                snap.Add(t.Key + "\t" + t.Name + "\tS:" + cs.Replace("\t", " ").Replace("\r", " ").Replace("\n", " "));
            }
            else
            {
                if (log != null) log("[!] Valor existente de outro tipo, ignorado: " + t.Name);
                continue;
            }
            todo.Add(t);
        }
        var file = Path.Combine(BackupDir, "snap_" + stamp + "_" + label + ".txt");
        File.WriteAllLines(file, snap);
        foreach (var key in todo.Select(x => x.Key).Distinct())
        {
            var safe = new string(key.Select(ch => char.IsLetterOrDigit(ch) ? ch : '_').ToArray());
            var shortKey = key.Replace("HKEY_CURRENT_USER", "HKCU").Replace("HKEY_LOCAL_MACHINE", "HKLM");
            var reg = Path.Combine(BackupDir, "reg_" + stamp + "_" + safe + ".reg");
            await Exec("reg.exe", "export \"" + shortKey + "\" \"" + reg + "\" /y", null);
        }
        if (log != null) log("[OK] Backup do Registro criado em " + BackupDir);
        if (!apply) return;
        int n = 0;
        foreach (var t in todo)
        {
            try
            {
                if (t.Value is int iv) Registry.SetValue(t.Key, t.Name, iv, RegistryValueKind.DWord);
                else Registry.SetValue(t.Key, t.Name, Convert.ToString(t.Value), RegistryValueKind.String);
                n++;
            }
            catch (Exception ex)
            {
                if (log != null) log("[X] " + t.Name + ": " + ex.Message);
            }
        }
        if (log != null) log("[OK] " + okMsg + " (" + n + " valores).");
    }

    // Mostra o valor atual e o novo, sem alterar nada.
    public static void Preview(Tw[] list, Action<string> log)
    {
        foreach (var t in list)
        {
            object cur = null;
            try { cur = Registry.GetValue(t.Key, t.Name, null); } catch { }
            var key = t.Key.Replace("HKEY_CURRENT_USER", "HKCU").Replace("HKEY_LOCAL_MACHINE", "HKLM");
            log("   " + key + "  " + t.Name + ":  " + (cur == null ? "(não existe)" : cur.ToString()) + "  ->  " + t.Value);
        }
    }

    public static string[] Snaps()
    {
        if (!Directory.Exists(BackupDir)) return new string[0];
        return Directory.GetFiles(BackupDir, "snap_*.txt").OrderByDescending(f => f).ToArray();
    }

    static void DeleteValue(string full, string name)
    {
        var i = full.IndexOf('\\');
        var hive = full.Substring(0, i);
        var sub = full.Substring(i + 1);
        RegistryKey root = null;
        if (hive == "HKEY_CURRENT_USER") root = Registry.CurrentUser;
        else if (hive == "HKEY_LOCAL_MACHINE") root = Registry.LocalMachine;
        if (root == null) return;
        using var k = root.OpenSubKey(sub, true);
        if (k != null) k.DeleteValue(name, false);
    }

    public static int RestoreFile(string file, Action<string> log)
    {
        int n = 0;
        foreach (var l in File.ReadAllLines(file))
        {
            var p = l.Split('\t');
            if (p.Length < 3) continue;
            try
            {
                var v = p[2];
                if (v == "-") DeleteValue(p[0], p[1]);
                else if (v.StartsWith("S:")) Registry.SetValue(p[0], p[1], v.Substring(2), RegistryValueKind.String);
                else Registry.SetValue(p[0], p[1], int.Parse(v.StartsWith("D:") ? v.Substring(2) : v), RegistryValueKind.DWord);
                n++;
            }
            catch (Exception ex)
            {
                if (log != null) log("[!] " + p[1] + ": " + ex.Message);
            }
        }
        try { File.Move(file, Path.ChangeExtension(file, ".restaurado")); } catch { }
        return n;
    }
}
