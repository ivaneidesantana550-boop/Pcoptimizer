# RHzin Optimizer 4.0 (Windows 10/11)

Programa unico (C# / .NET 8 WinForms) para notebook e PC, gerado como `.exe` pelo GitHub Actions.

- `src/Optimizer`: painel de otimizacao (login/senha/key do 3.1, categorias, sessoes de tweaks, log integrado).
- `src/Gerador`: gerador de licenca (mesmo formato `auth.dat` do pacote 3.1).
- `.github/workflows/build.yml`: compila os dois `.exe` (windows-latest, .NET 8, arquivo unico).

Resultado: aba **Actions** > ultima execucao > **Artifacts** > `RHzin_Optimizer_4_0`.
