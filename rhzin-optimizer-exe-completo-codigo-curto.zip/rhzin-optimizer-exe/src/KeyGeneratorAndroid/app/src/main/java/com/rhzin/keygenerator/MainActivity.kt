package com.rhzin.keygenerator

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import java.security.MessageDigest
import java.util.UUID

class MainActivity : android.app.Activity() {
    private lateinit var pin: EditText
    private lateinit var device: EditText
    private lateinit var client: EditText
    private lateinit var output: TextView
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun sha(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun token(size: Int): String = UUID.randomUUID().toString().replace("-", "").take(size)

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = Color.rgb(14, 24, 39)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(18)); setBackgroundColor(Color.rgb(10, 16, 27)) }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        val title = TextView(this).apply { text = "RHzin Key Generator"; textSize = 26f; setTextColor(Color.rgb(0,220,170)); gravity = Gravity.CENTER; setPadding(0,0,0,dp(8)) }
        root.addView(title)
        root.addView(TextView(this).apply { text = "PAINEL PRIVADO DO PROPRIETÁRIO"; textSize = 11f; setTextColor(Color.rgb(157,181,208)); gravity = Gravity.CENTER; setPadding(0,0,0,dp(20)) })
        pin = field("PIN do proprietário", true); root.addView(pin)
        client = field("Nome do cliente", false); root.addView(client)
        device = field("Código do PC do cliente (RZ-XXXXXXXXXXXX)", false); root.addView(device)
        root.addView(TextView(this).apply { text = "O cliente encontra este código no painel Windows em Informações do sistema."; textSize = 12f; setTextColor(Color.rgb(157,181,208)); setPadding(0,dp(4),0,dp(12)) })
        val generate = button("GERAR LOGIN • SENHA • KEY", Color.rgb(0,220,170), Color.rgb(4,22,26))
        root.addView(generate)
        output = TextView(this).apply { textSize = 16f; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(22,36,58)); setPadding(dp(14),dp(14),dp(14),dp(14)); setTextIsSelectable(true) }
        root.addView(output, LinearLayout.LayoutParams(-1, dp(170)).apply { topMargin = dp(16) })
        val copy = button("COPIAR DADOS", Color.rgb(46,156,255), Color.WHITE); root.addView(copy)
        status = TextView(this).apply { textSize = 12f; setTextColor(Color.rgb(157,181,208)); setPadding(0,dp(12),0,0) }; root.addView(status)

        generate.setOnClickListener { generateLicense() }
        copy.setOnClickListener { if (output.text.isNotBlank()) { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("RHzin licença", output.text)); status.text = "Dados copiados." } }
    }

    private fun field(label: String, password: Boolean) = EditText(this).apply { hint = label; textSize = 16f; setTextColor(Color.WHITE); setHintTextColor(Color.rgb(157,181,208)); setSingleLine(true); if (password) inputType = 0x00000081; setPadding(dp(12),0,dp(12),0); backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(42,68,101)); layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(10) } }
    private fun button(text: String, bg: Int, fg: Int) = Button(this).apply { this.text = text; setTextColor(fg); setBackgroundColor(bg); textSize = 14f; layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(10) } }

    private fun generateLicense() {
        if (BuildConfig.OWNER_PIN == "CHANGE_ME" || pin.text.toString() != BuildConfig.OWNER_PIN) { status.text = "PIN inválido."; status.setTextColor(Color.rgb(255,86,104)); return }
        val code = device.text.toString().trim().uppercase()
        if (!Regex("RZ-[A-Z0-9]{12}").matches(code)) { status.text = "Informe um código no formato RZ-XXXXXXXXXXXX."; return }
        if (client.text.toString().trim().isEmpty()) { status.text = "Informe o nome do cliente."; return }
        val login = "rz_" + token(8)
        val pass = token(14)
        val key = "RZ-${token(8)}-${token(8)}-${token(8)}"
        output.text = "CLIENTE: ${client.text}\nCÓDIGO: $code\nLOGIN : $login\nSENHA : $pass\nKEY   : $key\n\nHash interno:\n${sha(login)}|${sha(pass)}|${sha(key)}"
        status.text = "Licença pronta. Envie somente os dados ao cliente."
        status.setTextColor(Color.rgb(0,220,170))
    }
}
