plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.rhzin.keygenerator"; compileSdk = 35
    defaultConfig { applicationId = "com.rhzin.keygenerator.private"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0"; buildConfigField("String", "OWNER_PIN", "\"${(project.findProperty("ownerPin") as String?) ?: "CHANGE_ME"}\"") }
    buildFeatures { buildConfig = true }
}

kotlin { jvmToolchain(17) }
