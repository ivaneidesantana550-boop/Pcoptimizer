using System.Diagnostics;
using System.Text;
namespace RHzin;

static class SecurityTools
{
    public static async Task DefenderStatus(Action<string> log)
    {
        await Sys.PS("Get-MpComputerStatus | Select AMServiceEnabled,AntivirusEnabled,RealTimeProtectionEnabled,BehaviorMonitorEnabled,IoavProtectionEnabled,AntispywareEnabled,QuickScanAge,FullScanAge | Format-List", log);
    }

    public static Task QuickScan(Action<string> log) => Sys.PS("Update-MpSignature -ErrorAction SilentlyContinue; Start-MpScan -ScanType QuickScan", log);
    public static Task FullScan(Action<string> log) => Sys.PS("Update-MpSignature -ErrorAction SilentlyContinue; Start-MpScan -ScanType FullScan", log);
    public static Task EnableProtection(Action<string> log) => Sys.PS("Set-MpPreference -DisableRealtimeMonitoring $false -DisableBehaviorMonitoring $false -DisableIOAVProtection $false -DisableScriptScanning $false; Get-MpComputerStatus | Select RealTimeProtectionEnabled,BehaviorMonitorEnabled,IoavProtectionEnabled | Format-List", log);
    public static Task UpdateSignatures(Action<string> log) => Sys.PS("Update-MpSignature -ErrorAction Stop; (Get-MpComputerStatus).AntivirusSignatureVersion", log);
    public static Task MrtScan(Action<string> log) => Sys.Exec("mrt.exe", "/Q /F:Y", log);
    public static Task OpenDefender(Action<string> log) => Task.Run(() => Sys.Open("windowsdefender:", log));
    public static Task SecurityCenter(Action<string> log) => Sys.PS("Get-MpComputerStatus | Format-List; Get-MpThreatDetection -ErrorAction SilentlyContinue | Select ThreatName,Resources,InitialDetectionTime,ActionSuccess | Format-Table -Auto", log);

    public static async Task BackupHosts(Action<string> log)
    {
        var hosts = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "drivers", "etc", "hosts");
        var dir = Path.Combine(Auth.DataDir, "SecurityBackups");
        Directory.CreateDirectory(dir);
        var target = Path.Combine(dir, "hosts_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".bak");
        await Task.Run(() => File.Copy(hosts, target, true));
        log("[OK] Backup do hosts criado em " + target);
    }

    public static async Task HostsStatus(Action<string> log)
    {
        var hosts = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "drivers", "etc", "hosts");
        if (!File.Exists(hosts)) { log("[!] Arquivo hosts não encontrado."); return; }
        var lines = await File.ReadAllLinesAsync(hosts);
        var active = lines.Count(x => !string.IsNullOrWhiteSpace(x) && !x.TrimStart().StartsWith("#"));
        log("Entradas ativas no hosts: " + active);
        log("Arquivo: " + hosts);
    }

    public static Task AdBlockGuide(Action<string> log)
    {
        log("[INFO] Bloqueio de anúncios pode ser feito pelo navegador ou por DNS seguro.");
        log("[INFO] O RHzin não injeta extensões nem sobrescreve hosts sem uma lista confiável e confirmação.");
        log("[INFO] Abra as configurações de rede e use um DNS/filtro conhecido; faça backup do hosts antes.");
        return Task.Run(() => Sys.Open("ms-settings:network", log));
    }

    public static Task OpenSecuritySettings(Action<string> log) => Task.Run(() => Sys.Open("ms-settings:windowsdefender", log));
}
