using System.Text;
namespace RHzin;

static class MachineProfile
{
    public static List<Act> Cards(Action<string> log)
    {
        return new List<Act>
        {
            new Act { Title = "Detectar e recomendar perfil", Desc = "Analisa Windows, CPU, GPU, RAM, discos, placa-mãe e BIOS e mostra recomendações.", Run = () => Detect(log) },
            new Act { Title = "Relatório completo da máquina", Desc = "Gera relatório local de hardware e software para orientar os ajustes.", Run = () => Report(log) },
            new Act { Title = "Recomendações de BIOS", Desc = "Mostra opções seguras para conferir manualmente na BIOS, sem alterar firmware.", Run = () => BiosGuide(log) },
            new Act { Title = "Abrir suporte do fabricante", Desc = "Abre o site de suporte do fabricante detectado, quando possível.", Run = () => OpenSupport(log) },
            new Act { Title = "Preparar plano do Windows oficial", Desc = "Cria um plano e um autounattend.xml seguro para mídia oficial; não formata nem instala sozinho.", Confirm = "Criar os arquivos de preparação do Windows oficial? Nenhum disco será formatado.", Run = () => PrepareWindows(log) },
            new Act { Title = "Abrir download oficial do Windows", Desc = "Abre a página oficial da Microsoft para baixar a mídia original.", Run = () => Task.Run(() => Sys.Open("https://www.microsoft.com/software-download/windows11", log)) },
            new Act { Title = "Abrir configurações de inicialização", Desc = "Abre as opções oficiais de recuperação e inicialização do Windows.", Run = () => Task.Run(() => Sys.Open("ms-settings:recovery", log)) },
        };
    }

    static Task Detect(Action<string> log) => Sys.PS(@"$os=Get-CimInstance Win32_OperatingSystem; $cs=Get-CimInstance Win32_ComputerSystem; $cpu=Get-CimInstance Win32_Processor; $gpu=Get-CimInstance Win32_VideoController; $bios=Get-CimInstance Win32_BIOS; '=== PERFIL AUTOMÁTICO ==='; 'Sistema: '+$os.Caption+' '+$os.OSArchitecture; 'Fabricante/modelo: '+$cs.Manufacturer+' '+$cs.Model; 'RAM: '+[math]::Round($cs.TotalPhysicalMemory/1GB,1)+' GB'; 'CPU: '+$cpu.Name; 'GPU: '+(($gpu.Name -join '; ')); 'BIOS: '+$bios.Manufacturer+' '+$bios.SMBIOSBIOSVersion; if ($cs.TotalPhysicalMemory -lt 8GB) {'Perfil recomendado: econômico — priorizar efeitos leves e limpeza.'} elseif ($cs.TotalPhysicalMemory -lt 16GB) {'Perfil recomendado: equilibrado — ajustes moderados.'} else {'Perfil recomendado: desempenho — manter efeitos e priorizar jogos.'}", log);
    static Task Report(Action<string> log) => Sys.PS(@"$dir=Join-Path $env:ProgramData 'RHzin_Optimizer\Reports'; New-Item -ItemType Directory -Force $dir | Out-Null; $file=Join-Path $dir ('machine_'+(Get-Date -Format yyyyMMdd_HHmmss)+'.txt'); Get-CimInstance Win32_OperatingSystem,Win32_ComputerSystem,Win32_Processor,Win32_VideoController,Win32_BIOS | Out-File $file; 'Relatório criado: '+$file; Start-Process notepad.exe $file", log);
    static Task BiosGuide(Action<string> log) => Sys.PS(@"$b=Get-CimInstance Win32_BIOS; $c=Get-CimInstance Win32_ComputerSystem; '=== GUIA BIOS ==='; 'Fabricante: '+$c.Manufacturer; 'Modelo: '+$c.Model; 'BIOS: '+$b.SMBIOSBIOSVersion; 'Confira manualmente: virtualização (Intel VT-x/AMD SVM), XMP/EXPO da memória, UEFI/GPT, Secure Boot e TPM 2.0.'; 'Não altere voltagem, clocks ou firmware sem consultar o manual do fabricante.'", log);
    static Task OpenSupport(Action<string> log) => Task.Run(() => Sys.Open("https://support.microsoft.com/windows", log));
    static async Task PrepareWindows(Action<string> log)
    {
        var dir=Path.Combine(Auth.DataDir,"WindowsSetup"); Directory.CreateDirectory(dir);
        var plan=Path.Combine(dir,"PLANO-INSTALACAO-WINDOWS.md");
        var xml=Path.Combine(dir,"autounattend.xml");
        await File.WriteAllTextAsync(plan,"# Plano seguro de instalação\n\n1. Baixe a ISO exclusivamente da Microsoft.\n2. Faça backup dos arquivos pessoais.\n3. Crie um USB com a Media Creation Tool ou Rufus.\n4. Confirme partições e edição manualmente.\n5. Este programa não apaga discos nem inicia instalação automática.\n");
        await File.WriteAllTextAsync(xml,"<?xml version=\"1.0\" encoding=\"utf-8\"?><unattend xmlns=\"urn:schemas-microsoft-com:unattend\"><!-- Modelo mínimo: preencha idioma, edição e partições manualmente antes de usar. --></unattend>");
        log("[OK] Plano criado: "+plan); log("[OK] Modelo criado: "+xml); log("[!] A instalação continua manual e exige confirmação fora do aplicativo.");
    }
}
