using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32;

namespace RHzin;

// Mesmo formato do pacote 3.1: %ProgramData%\RHzin_Optimizer\Auth\auth.dat
// Linha unica: DISPOSITIVO|MACHINEGUID|SHA256(login)|SHA256(senha)|SHA256(key)
static class Auth
{
    public static readonly string DataDir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "RHzin_Optimizer");
    public static readonly string AuthDir = Path.Combine(DataDir, "Auth");
    public static readonly string AuthFile = Path.Combine(AuthDir, "auth.dat");

    public class Lic
    {
        public string Device;
        public string MachineId;
        public string UserHash;
        public string PassHash;
        public string KeyHash;
    }

    public static string MachineGuid()
    {
        try
        {
            using var root = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
            using var k = root.OpenSubKey(@"SOFTWARE\Microsoft\Cryptography");
            return (k == null ? null : k.GetValue("MachineGuid") as string) ?? "";
        }
        catch
        {
            return "";
        }
    }

    public static string Sha(string s)
    {
        var h = SHA256.HashData(Encoding.UTF8.GetBytes(s ?? ""));
        return Convert.ToHexString(h).ToLowerInvariant();
    }

    // Código curto exibido ao cliente; o GUID completo nunca precisa ser enviado.
    public static string DeviceCode()
    {
        var digest = Sha("RHzin-Device-Code-v1|" + MachineGuid());
        return "RZ-" + digest.Substring(0, 12).ToUpperInvariant();
    }

    public static Lic Read()
    {
        try
        {
            if (!File.Exists(AuthFile)) return null;
            var line = File.ReadLines(AuthFile).FirstOrDefault();
            if (string.IsNullOrWhiteSpace(line)) return null;
            var p = line.Split('|');
            if (p.Length < 5) return null;
            return new Lic
            {
                Device = p[0].Trim(),
                MachineId = p[1].Trim(),
                UserHash = p[2].Trim(),
                PassHash = p[3].Trim(),
                KeyHash = p[4].Trim()
            };
        }
        catch
        {
            return null;
        }
    }

    static bool Eq(string a, string b)
    {
        return string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
    }

    // Retorna null se estiver tudo certo, ou a mensagem de erro.
    public static string Validate(string user, string pass, string key)
    {
        var l = Read();
        if (l == null) return "Nenhuma licença encontrada neste computador. Gere uma com o Gerador de Licença.";
        if (!Eq(l.MachineId, DeviceCode())) return "Esta licença pertence a outro computador (" + l.Device + "). Código deste PC: " + DeviceCode();
        bool ok = Eq(Sha(user), l.UserHash) && Eq(Sha(pass), l.PassHash) && Eq(Sha(key), l.KeyHash);
        return ok ? null : "Login, senha ou key inválidos.";
    }

    public static string Resumo()
    {
        var l = Read();
        return l == null ? "—" : l.Device;
    }

    public static (string login, string pass, string key) Create(string device)
    {
        string G() { return Guid.NewGuid().ToString("N"); }
        var login = "rz_" + G().Substring(0, 8);
        var pass = G().Substring(0, 14);
        var key = "RZ-" + G().Substring(0, 8) + "-" + G().Substring(0, 8) + "-" + G().Substring(0, 8);
        Directory.CreateDirectory(AuthDir);
        if (File.Exists(AuthFile)) File.SetAttributes(AuthFile, FileAttributes.Normal);
        var line = string.Join("|", device.Replace("|", " "), device.Trim(), Sha(login), Sha(pass), Sha(key));
        File.WriteAllText(AuthFile, line);
        File.SetAttributes(AuthFile, FileAttributes.Hidden);
        return (login, pass, key);
    }

    public static void Remove()
    {
        if (!File.Exists(AuthFile)) return;
        File.SetAttributes(AuthFile, FileAttributes.Normal);
        File.Delete(AuthFile);
    }
}
