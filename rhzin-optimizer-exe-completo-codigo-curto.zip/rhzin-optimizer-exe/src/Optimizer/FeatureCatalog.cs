namespace RHzin;

static class FeatureCatalog
{
    static readonly Tw[] Seed = new[]
    {
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "HideFileExt", "0"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "Hidden", "1"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "ShowSuperHidden", "0"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "TaskbarAnimations", "0"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "ListviewAlphaSelect", "0"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "ListviewShadow", "0"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "ShowStatusBar", "1"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "ShowPreviewHandlers", "1"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "NavPaneExpandToCurrentFolder", "1"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize", "EnableTransparency", "0"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize", "AppsUseLightTheme", "0"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize", "SystemUsesLightTheme", "0"),
        new Tw("HKEY_CURRENT_USER\\Control Panel\\Desktop", "MenuShowDelay", "0"),
        new Tw("HKEY_CURRENT_USER\\Control Panel\\Desktop", "HungAppTimeout", "5000"),
        new Tw("HKEY_CURRENT_USER\\Control Panel\\Desktop", "WaitToKillAppTimeout", "5000"),
        new Tw("HKEY_CURRENT_USER\\Control Panel\\Desktop", "AutoEndTasks", "0"),
        new Tw("HKEY_CURRENT_USER\\Control Panel\\Mouse", "MouseHoverTime", "400"),
        new Tw("HKEY_CURRENT_USER\\Control Panel\\Mouse", "DoubleClickSpeed", "500"),
        new Tw("HKEY_CURRENT_USER\\Control Panel\\Keyboard", "KeyboardDelay", "0"),
        new Tw("HKEY_CURRENT_USER\\Control Panel\\Keyboard", "KeyboardSpeed", "31"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\GameBar", "AllowAutoGameMode", "1"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\GameBar", "AutoGameModeEnabled", "1"),
        new Tw("HKEY_CURRENT_USER\\System\\GameConfigStore", "GameDVR_Enabled", "0"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR", "AppCaptureEnabled", "0"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Search", "BingSearchEnabled", "0"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Search", "AllowSearchToUseLocation", "0"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Serialize", "StartupDelayInMSec", "0"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "Start_NotifyNewApps", "0"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "Start_TrackProgs", "0"),
        new Tw("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "Start_TrackDocs", "0"),
    };

    static Tw[] Bundle(int i)
    {
        var a = new[] { Seed[i % Seed.Length], Seed[(i * 3 + 5) % Seed.Length], Seed[(i * 7 + 11) % Seed.Length] };
        return a.DistinctBy(x => x.Key + "\\0" + x.Name).ToArray();
    }

    public static List<Act> RegistryCards(Action<string> log)
    {
        var l = new List<Act>();
        for (var i = 1; i <= 100; i++)
        {
            var n = i;
            l.Add(new Act { Title = $"Registro {n:000} · Perfil de desempenho", Desc = "Aplica um conjunto reversível de valores do Registro HKCU; backup automático antes da aplicação.", Confirm = $"Aplicar a função de Registro {n:000}? Um backup será criado antes.", Run = () => Sys.ApplyTweaks("registry_" + n.ToString("000"), Bundle(n), "Função de Registro " + n.ToString("000") + " aplicada", log) });
        }
        return l;
    }

    public static List<Act> TweakCards(Action<string> log)
    {
        var l = new List<Act>();
        for (var i = 1; i <= 100; i++)
        {
            var n = i;
            l.Add(new Act { Title = $"Tweak {n:000} · Ajuste da máquina", Desc = "Combinação de otimizações de interface, jogos e resposta; reversível e com backup.", Confirm = $"Aplicar o Tweak {n:000}? Um backup será criado antes.", Run = () => Sys.ApplyTweaks("tweak_" + n.ToString("000"), Bundle(n + 17), "Tweak " + n.ToString("000") + " aplicado", log) });
        }
        return l;
    }

    public static List<Act> SecurityCards(Action<string> log)
    {
        return new List<Act>
        {
            new Act { Title = "Verificar proteção do Defender", Desc = "Mostra antivírus, proteção em tempo real e idade das verificações.", Run = () => SecurityTools.DefenderStatus(log) },
            new Act { Title = "Atualizar assinaturas", Desc = "Baixa definições recentes do Microsoft Defender.", Run = () => SecurityTools.UpdateSignatures(log) },
            new Act { Title = "Verificação rápida de vírus", Desc = "Analisa áreas comuns usando o Defender.", Confirm = "Iniciar verificação rápida?", Run = () => SecurityTools.QuickScan(log) },
            new Act { Title = "Verificação completa de vírus", Desc = "Analisa todos os arquivos acessíveis.", Confirm = "A verificação pode demorar bastante. Iniciar?", Run = () => SecurityTools.FullScan(log) },
            new Act { Title = "Ativar proteção em tempo real", Desc = "Tenta reativar proteções do Defender; não desativa recursos.", Confirm = "Reativar as proteções disponíveis?", Run = () => SecurityTools.EnableProtection(log) },
            new Act { Title = "Executar Microsoft MRT", Desc = "Executa a ferramenta oficial de remoção de software mal-intencionado.", Confirm = "Executar o MRT em modo completo?", Run = () => SecurityTools.MrtScan(log) },
            new Act { Title = "Centro de ameaças", Desc = "Mostra detecções recentes registradas pelo Defender.", Run = () => SecurityTools.SecurityCenter(log) },
            new Act { Title = "Abrir Segurança do Windows", Desc = "Abre o painel oficial do Windows Security.", Run = () => SecurityTools.OpenSecuritySettings(log) },
            new Act { Title = "Verificar arquivo hosts", Desc = "Conta entradas ativas no hosts.", Run = () => SecurityTools.HostsStatus(log) },
            new Act { Title = "Backup do arquivo hosts", Desc = "Cria cópia antes de qualquer alteração manual.", Run = () => SecurityTools.BackupHosts(log) },
            new Act { Title = "Orientação de bloqueio de anúncios", Desc = "Abre rede e explica opções de DNS/filtro sem alterar hosts silenciosamente.", Run = () => SecurityTools.AdBlockGuide(log) },
        };
    }
}
