# RHzin Optimizer 4.0 (Windows 10/11)

Programa unico (C# / .NET 8 WinForms) para notebook e PC, gerado como `.exe` pelo GitHub Actions.

- `src/Optimizer`: painel de otimizacao (login/senha/key do 3.1, categorias, sessoes de tweaks, log integrado).
- `src/Gerador`: gerador de licenca (mesmo formato `auth.dat` do pacote 3.1).
- `.github/workflows/build.yml`: compila os dois `.exe` (windows-latest, .NET 8, arquivo unico).

Resultado: aba **Actions** > ultima execucao > **Artifacts** > `RHzin_Optimizer_4_0`.

## Módulos avançados desta versão

- Perfil automático com leitura de sistema, CPU, GPU, RAM, discos, placa-mãe e BIOS.
- Guia de BIOS seguro e somente informativo; o aplicativo não grava firmware.
- Preparação de um plano de instalação do Windows oficial e `autounattend.xml` modelo; o aplicativo não formata discos nem instala Windows silenciosamente.
- Segurança com status do Microsoft Defender, atualização de assinaturas, verificação rápida, verificação completa, MRT, ameaças recentes e reativação da proteção em tempo real.
- Verificação e backup do arquivo `hosts` antes de qualquer manutenção manual.
- Sessão `Registro · 100 funções` com 100 ações catalogadas, reversíveis e com backup por ação.
- Sessão `Tweaks · 100 funções` com 100 combinações de ajustes reversíveis no perfil do usuário.
- Paleta do painel atualizada para azul escuro, ciano e verde neon, com maior contraste.

As funções do Registro e os tweaks gravam somente valores de usuário ou configurações documentadas no catálogo. Cada aplicação cria snapshot antes da alteração. Resultados de desempenho variam por máquina; não há promessa de ganho universal.
